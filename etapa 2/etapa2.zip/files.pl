:- ensure_loaded('points2.pl').
:- ensure_loaded('utils.pl').
:- ensure_loaded('testing.pl').
:- ensure_loaded('checker.pl').
